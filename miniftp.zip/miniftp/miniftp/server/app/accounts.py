"""Учётные записи: хранение пароля (PBKDF2) и секрета аппаратного USB-ключа."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

PBKDF2_ITER = 200_000
KEY_FILE_NAME = ".auth_token.key"
KEY_HEADER = "MFTP-KEY v1"


@dataclass
class User:
    name: str
    pwd_salt: bytes
    pwd_hash: bytes
    pwd_iter: int
    key_id: str
    key_secret: bytes


def _hash_password(password: str, salt: bytes, iterations: int) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)


def key_checksum(user: str, key_id: str, secret_b64: str) -> str:
    """Контрольная сумма файла-ключа (клиент проверяет целостность до подключения)."""
    data = f"{KEY_HEADER}|{user}|{key_id}|{secret_b64}".encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def render_key_file(user: str, key_id: str, secret: bytes) -> str:
    secret_b64 = base64.b64encode(secret).decode()
    return (
        f"{KEY_HEADER}\n"
        f"user={user}\n"
        f"key_id={key_id}\n"
        f"secret={secret_b64}\n"
        f"check={key_checksum(user, key_id, secret_b64)}\n"
    )


def compute_key_proof(secret: bytes, nonce: bytes, user: str) -> str:
    """Ответ на challenge: HMAC-SHA256(secret, nonce || user)."""
    return hmac.new(secret, nonce + user.encode("utf-8"), hashlib.sha256).hexdigest()


class UserStore:
    """Потокобезопасное хранилище пользователей в JSON-файле."""

    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.Lock()
        self._users: dict[str, User] = {}
        self._mtime = 0.0
        self.reload()

    def reload_if_changed(self) -> None:
        """Подхватывает изменения users.json (manage_users.py) без рестарта."""
        try:
            mtime = self.path.stat().st_mtime
        except FileNotFoundError:
            return
        if mtime != self._mtime:
            self.reload()

    def reload(self) -> None:
        with self._lock:
            self._users = {}
            if not self.path.exists():
                return
            self._mtime = self.path.stat().st_mtime
            raw = json.loads(self.path.read_text("utf-8"))
            for name, u in raw.get("users", {}).items():
                self._users[name] = User(
                    name=name,
                    pwd_salt=bytes.fromhex(u["pwd_salt"]),
                    pwd_hash=bytes.fromhex(u["pwd_hash"]),
                    pwd_iter=int(u["pwd_iter"]),
                    key_id=u["key_id"],
                    key_secret=base64.b64decode(u["key_secret"]),
                )

    def _save(self) -> None:
        data = {"users": {
            u.name: {
                "pwd_salt": u.pwd_salt.hex(),
                "pwd_hash": u.pwd_hash.hex(),
                "pwd_iter": u.pwd_iter,
                "key_id": u.key_id,
                "key_secret": base64.b64encode(u.key_secret).decode(),
            } for u in self._users.values()}}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), "utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(self.path)
        self._mtime = self.path.stat().st_mtime

    def get(self, name: str) -> Optional[User]:
        with self._lock:
            return self._users.get(name)

    def names(self) -> list[str]:
        with self._lock:
            return sorted(self._users)

    def upsert(self, name: str, password: str, rotate_key: bool = True) -> tuple[User, str]:
        """Создаёт/обновляет пользователя; возвращает (user, содержимое .auth_token.key)."""
        with self._lock:
            old = self._users.get(name)
            salt = secrets.token_bytes(16)
            if rotate_key or old is None:
                key_id, key_secret = secrets.token_hex(8), secrets.token_bytes(32)
            else:
                key_id, key_secret = old.key_id, old.key_secret
            user = User(name, salt, _hash_password(password, salt, PBKDF2_ITER),
                        PBKDF2_ITER, key_id, key_secret)
            self._users[name] = user
            self._save()
            return user, render_key_file(name, key_id, key_secret)

    def rotate_key(self, name: str) -> str:
        """Перевыпуск USB-ключа без смены пароля (старый ключ перестаёт работать)."""
        with self._lock:
            u = self._users[name]
            u.key_id, u.key_secret = secrets.token_hex(8), secrets.token_bytes(32)
            self._save()
            return render_key_file(name, u.key_id, u.key_secret)

    def remove(self, name: str) -> bool:
        with self._lock:
            if self._users.pop(name, None) is None:
                return False
            self._save()
            return True

    def verify(self, name: str, password: str, key_id: str, proof_hex: str,
               nonce: bytes) -> tuple[bool, bool]:
        """Возвращает (пароль_верен, ключ_верен). Сравнения — за постоянное время."""
        self.reload_if_changed()
        user = self.get(name)
        if user is None:
            # фиктивный расчёт, чтобы время ответа не выдавало наличие логина
            _hash_password(password, b"\0" * 16, PBKDF2_ITER)
            return False, False
        pwd_ok = hmac.compare_digest(
            _hash_password(password, user.pwd_salt, user.pwd_iter), user.pwd_hash)
        expected = compute_key_proof(user.key_secret, nonce, name)
        key_ok = hmac.compare_digest(key_id, user.key_id) and \
            hmac.compare_digest(proof_hex.lower(), expected)
        return pwd_ok, key_ok
