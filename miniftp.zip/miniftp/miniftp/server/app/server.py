"""
MiniFTP — многопоточный TCP-сервер файлового хранилища (протокол MFTP/1).

Модель: ThreadingTCPServer — на каждое TCP-соединение отдельный поток.
Число одновременных сессий ограничено семафором (MFTP_MAX_CLIENTS).
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import secrets
import shutil
import signal
import socket
import socketserver
import threading
import time
from pathlib import Path

from accounts import KEY_FILE_NAME, UserStore
from protocol import (CHUNK, ConnectionClosed, Frame, Op, ProtocolError, Status,
                      discard_payload, read_frame_header, send_frame, stream_payload_to)

# ---------------------------------------------------------------- конфигурация
HOST = os.getenv("MFTP_HOST", "0.0.0.0")
PORT = int(os.getenv("MFTP_PORT", "2121"))
STORAGE = Path(os.getenv("MFTP_STORAGE", "/data/storage")).resolve()
USERS_FILE = Path(os.getenv("MFTP_USERS", "/data/config/users.json"))
KEYS_DIR = Path(os.getenv("MFTP_KEYS_DIR", "/data/config/keys"))
MAX_CLIENTS = int(os.getenv("MFTP_MAX_CLIENTS", "32"))
IDLE_TIMEOUT = float(os.getenv("MFTP_IDLE_TIMEOUT", "300"))
MAX_AUTH_ATTEMPTS = 3                 # попыток на одно соединение
LOCKOUT_FAILS, LOCKOUT_SECONDS = 5, 60  # блокировка логина после 5 неудач

logging.basicConfig(level=os.getenv("MFTP_LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s [%(threadName)s] %(message)s")
log = logging.getLogger("miniftp")

store = UserStore(USERS_FILE)
slots = threading.BoundedSemaphore(MAX_CLIENTS)


class LoginThrottle:
    """Блокировка по ЛОГИНУ, а не по IP: за туннелем CloudPub все клиенты
    приходят с одного адреса, и блокировка по IP заблокировала бы всех."""

    def __init__(self):
        self._lock = threading.Lock()
        self._fails: dict[str, list[float]] = {}

    def locked(self, user: str) -> bool:
        with self._lock:
            now = time.monotonic()
            recent = [t for t in self._fails.get(user, []) if now - t < LOCKOUT_SECONDS]
            self._fails[user] = recent
            return len(recent) >= LOCKOUT_FAILS

    def fail(self, user: str) -> None:
        with self._lock:
            self._fails.setdefault(user, []).append(time.monotonic())

    def reset(self, user: str) -> None:
        with self._lock:
            self._fails.pop(user, None)


throttle = LoginThrottle()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


class Session(socketserver.BaseRequestHandler):
    """Обработчик одного TCP-соединения (выполняется в отдельном потоке)."""

    def setup(self):
        self.sock: socket.socket = self.request
        self.sock.settimeout(IDLE_TIMEOUT)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.user: str | None = None
        self.root: Path | None = None
        self.nonce = secrets.token_bytes(32)
        self.peer = "%s:%s" % self.client_address[:2]

    # ------------------------------------------------------------- цикл сессии
    def handle(self):
        if not slots.acquire(blocking=False):
            send_frame(self.sock, Op.ERROR, {"message": "server busy"}, Status.RATE_LIMITED)
            return
        try:
            log.debug("connect %s", self.peer)
            send_frame(self.sock, Op.HELLO, {"server": "MiniFTP", "proto": 1,
                                             "nonce": self.nonce.hex()})
            auth_attempts = 0
            while True:
                frame = read_frame_header(self.sock)
                try:
                    if frame.opcode == Op.BYE:
                        send_frame(self.sock, Op.OK, {"message": "bye"})
                        return
                    if frame.opcode == Op.AUTH:
                        auth_attempts += 1
                        self.do_auth(frame)
                        continue
                    if self.user is None:
                        raise ProtocolError(Status.AUTH_REQUIRED, "authenticate first")
                    handler = {
                        Op.LIST: self.do_list, Op.UPLOAD: self.do_upload,
                        Op.DOWNLOAD: self.do_download, Op.DELETE: self.do_delete,
                        Op.MKDIR: self.do_mkdir, Op.PING: self.do_ping,
                    }.get(frame.opcode)
                    if handler is None:
                        raise ProtocolError(Status.BAD_REQUEST, f"unknown opcode 0x{frame.opcode:02X}")
                    try:
                        handler(frame)
                    except OSError as e:  # ошибки ФС не должны рвать сессию
                        log.exception("fs error user=%s", self.user)
                        raise ProtocolError(Status.INTERNAL, f"server I/O error: {e.strerror}")
                except ProtocolError as e:
                    # payload не обработан — вычитываем его, чтобы поток не рассинхронизировался
                    if frame.payload_len and not getattr(e, "payload_consumed", False):
                        discard_payload(self.sock, frame.payload_len)
                    send_frame(self.sock, Op.ERROR, {"message": e.message}, e.status)
                    if self.user is None and auth_attempts >= MAX_AUTH_ATTEMPTS:
                        log.warning("too many auth attempts from %s, closing", self.peer)
                        return
        except (ConnectionClosed, ConnectionResetError, BrokenPipeError):
            pass
        except socket.timeout:
            log.info("idle timeout %s", self.peer)
        except ProtocolError as e:  # ошибка разбора заголовка — поток не восстановить
            try:
                send_frame(self.sock, Op.ERROR, {"message": e.message}, e.status)
            except OSError:
                pass
        except Exception:
            log.exception("unhandled error in session %s", self.peer)
        finally:
            slots.release()
            (log.info if self.user else log.debug)("disconnect %s user=%s", self.peer, self.user)

    # ------------------------------------------------------------ безопасность
    def resolve(self, client_path: str, must_exist: bool = True) -> Path:
        """Перевод пути клиента в путь внутри домашнего каталога пользователя.
        Защита от path traversal (../) и выхода по симлинкам."""
        if not isinstance(client_path, str) or "\0" in client_path:
            raise ProtocolError(Status.BAD_REQUEST, "invalid path")
        parts = [x for x in client_path.replace("\\", "/").split("/") if x not in ("", ".")]
        target = self.root.joinpath(*parts).resolve()
        if target != self.root and self.root not in target.parents:
            raise ProtocolError(Status.FORBIDDEN, "path escapes user root")
        if must_exist and not target.exists():
            raise ProtocolError(Status.NOT_FOUND, f"not found: {client_path}")
        return target

    def to_client(self, p: Path) -> str:
        rel = p.relative_to(self.root).as_posix()
        return "/" if rel == "." else "/" + rel

    # ---------------------------------------------------------------- команды
    def do_auth(self, f: Frame):
        user = str(f.meta.get("user", ""))
        if self.user is not None:
            raise ProtocolError(Status.BAD_REQUEST, "already authenticated")
        if throttle.locked(user):
            raise ProtocolError(Status.RATE_LIMITED, "too many failures, try later")
        pwd_ok, key_ok = store.verify(user, str(f.meta.get("password", "")),
                                      str(f.meta.get("key_id", "")),
                                      str(f.meta.get("key_proof", "")), self.nonce)
        if not pwd_ok:
            throttle.fail(user)
            log.warning("auth failed (password) user=%r from %s", user, self.peer)
            raise ProtocolError(Status.AUTH_FAILED, "invalid login or password")
        if not key_ok:
            throttle.fail(user)
            log.warning("auth failed (USB key) user=%r from %s", user, self.peer)
            raise ProtocolError(Status.KEY_REJECTED, "hardware key rejected")
        throttle.reset(user)
        self.user = user
        self.root = (STORAGE / user).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        log.info("auth ok user=%s from %s", user, self.peer)
        send_frame(self.sock, Op.OK, {"user": user, "home": "/"})

    def do_ping(self, f: Frame):
        send_frame(self.sock, Op.OK, {"time": time.time()})

    def do_list(self, f: Frame):
        target = self.resolve(f.meta.get("path", "/"))
        if not target.is_dir():
            raise ProtocolError(Status.BAD_REQUEST, "not a directory")
        entries = []
        for p in sorted(target.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            if p.name.endswith(".mftp-part"):
                continue
            st = p.stat()
            entries.append({"name": p.name, "type": "dir" if p.is_dir() else "file",
                            "size": 0 if p.is_dir() else st.st_size, "mtime": int(st.st_mtime)})
        body = json.dumps(entries, ensure_ascii=False).encode("utf-8")
        send_frame(self.sock, Op.DATA, {"path": self.to_client(target), "count": len(entries),
                                        "encoding": "json"}, payload=body)

    def do_upload(self, f: Frame):
        dest = self.resolve(f.meta.get("path", ""), must_exist=False)
        size = int(f.meta.get("size", -1))
        expected = str(f.meta.get("sha256", "")).lower()
        if size != f.payload_len:
            raise ProtocolError(Status.BAD_REQUEST, "meta.size != payload_len")
        if dest == self.root or dest.is_dir():
            raise ProtocolError(Status.BAD_REQUEST, "destination is a directory")
        if not dest.parent.is_dir():
            raise ProtocolError(Status.NOT_FOUND, "parent directory does not exist")
        if dest.exists() and not f.meta.get("overwrite", False):
            raise ProtocolError(Status.ALREADY_EXISTS, "file exists")
        if shutil.disk_usage(dest.parent).free < size:
            raise ProtocolError(Status.TOO_LARGE, "not enough space on server")

        part = dest.with_name(dest.name + f".{secrets.token_hex(4)}.mftp-part")
        h = hashlib.sha256()
        try:
            with part.open("wb") as out:
                stream_payload_to(self.sock, size, out, h.update)
            if expected and h.hexdigest() != expected:
                err = ProtocolError(Status.CHECKSUM_MISMATCH, "sha256 mismatch")
                err.payload_consumed = True
                raise err
            part.replace(dest)  # атомарная замена: недокачанный файл не виден в LIST
        finally:
            part.unlink(missing_ok=True)
        log.info("upload user=%s %s (%d B)", self.user, self.to_client(dest), size)
        send_frame(self.sock, Op.OK, {"path": self.to_client(dest), "size": size,
                                      "sha256": h.hexdigest()})

    def do_download(self, f: Frame):
        src = self.resolve(f.meta.get("path", ""))
        if not src.is_file():
            raise ProtocolError(Status.BAD_REQUEST, "not a file")
        digest = sha256_file(src)
        size = src.stat().st_size
        send_frame(self.sock, Op.DATA, {"name": src.name, "size": size, "sha256": digest,
                                        "mtime": int(src.stat().st_mtime)}, payload_len=size)
        with src.open("rb") as fh:  # zero-copy отдача (sendfile) там, где ОС поддерживает
            sent = self.sock.sendfile(fh, 0, size)
        if sent != size:
            raise ConnectionClosed("short sendfile")
        log.info("download user=%s %s (%d B)", self.user, self.to_client(src), size)

    def do_delete(self, f: Frame):
        target = self.resolve(f.meta.get("path", ""))
        if target == self.root:
            raise ProtocolError(Status.FORBIDDEN, "cannot delete home directory")
        if target.is_dir():
            if f.meta.get("recursive"):
                shutil.rmtree(target)
            else:
                try:
                    target.rmdir()
                except OSError:
                    raise ProtocolError(Status.BAD_REQUEST, "directory not empty")
        else:
            target.unlink()
        log.info("delete user=%s %s", self.user, f.meta.get("path"))
        send_frame(self.sock, Op.OK, {})

    def do_mkdir(self, f: Frame):
        target = self.resolve(f.meta.get("path", ""), must_exist=False)
        if target.exists():
            raise ProtocolError(Status.ALREADY_EXISTS, "already exists")
        target.mkdir(parents=True)
        send_frame(self.sock, Op.OK, {"path": self.to_client(target)})


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 64


def bootstrap_user() -> None:
    """Если пользователей нет — создать из переменных окружения и выпустить ключ."""
    name, pwd = os.getenv("MFTP_BOOTSTRAP_USER"), os.getenv("MFTP_BOOTSTRAP_PASSWORD")
    if not name or not pwd or store.get(name):
        return
    _, key_text = store.upsert(name, pwd)
    KEYS_DIR.mkdir(parents=True, exist_ok=True)
    key_path = KEYS_DIR / f"{name}{KEY_FILE_NAME}"
    key_path.write_text(key_text, "utf-8")
    os.chmod(key_path, 0o600)
    log.warning("bootstrap user %r created; USB key written to %s — "
                "copy it to a flash drive as %s and delete it from the server",
                name, key_path, KEY_FILE_NAME)


def main():
    STORAGE.mkdir(parents=True, exist_ok=True)
    bootstrap_user()
    if not store.names():
        log.error("no users configured: run manage_users.py add <user> or set MFTP_BOOTSTRAP_*")
    srv = Server((HOST, PORT), Session)
    signal.signal(signal.SIGTERM, lambda *_: threading.Thread(target=srv.shutdown).start())
    log.info("MiniFTP listening on %s:%d, storage=%s, max_clients=%d",
             HOST, PORT, STORAGE, MAX_CLIENTS)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        log.info("stopped")


if __name__ == "__main__":
    main()
