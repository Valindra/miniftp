"""
Управление пользователями и выпуск аппаратных USB-ключей.

    python manage_users.py add Test "Test123331=" --key-out /data/config/keys
    python manage_users.py passwd Test "NewPass" --keep-key
    python manage_users.py rekey Test --key-out /data/config/keys
    python manage_users.py list
    python manage_users.py remove Test

Сгенерированный файл <user>.auth_token.key нужно скопировать в КОРЕНЬ флешки
под именем .auth_token.key, после чего удалить с сервера.
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

from accounts import KEY_FILE_NAME, UserStore

USERS_FILE = Path(os.getenv("MFTP_USERS", "/data/config/users.json"))


def write_key(out_dir: str, user: str, text: str) -> None:
    path = Path(out_dir) / f"{user}{KEY_FILE_NAME}"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, "utf-8")
    os.chmod(path, 0o600)
    print(f"[+] USB-ключ записан: {path}")
    print(f"    Скопируйте его в корень флешки под именем {KEY_FILE_NAME}")


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="MiniFTP user management")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("add", "passwd"):
        s = sub.add_parser(name)
        s.add_argument("user")
        s.add_argument("password", nargs="?", help="если не указан — будет запрошен")
        s.add_argument("--key-out", default=str(USERS_FILE.parent / "keys"))
        if name == "passwd":
            s.add_argument("--keep-key", action="store_true", help="не перевыпускать USB-ключ")
    r = sub.add_parser("rekey")
    r.add_argument("user")
    r.add_argument("--key-out", default=str(USERS_FILE.parent / "keys"))
    sub.add_parser("list")
    rm = sub.add_parser("remove")
    rm.add_argument("user")
    a = p.parse_args(argv)

    store = UserStore(USERS_FILE)
    if a.cmd in ("add", "passwd"):
        if a.cmd == "add" and store.get(a.user):
            print("пользователь уже существует (используйте passwd/rekey)", file=sys.stderr)
            return 1
        if a.cmd == "passwd" and not store.get(a.user):
            print("пользователь не найден", file=sys.stderr)
            return 1
        pwd = a.password or getpass.getpass("Пароль: ")
        _, key = store.upsert(a.user, pwd, rotate_key=not getattr(a, "keep_key", False))
        print(f"[+] пользователь {a.user} сохранён")
        if not getattr(a, "keep_key", False):
            write_key(a.key_out, a.user, key)
    elif a.cmd == "rekey":
        if not store.get(a.user):
            print("пользователь не найден", file=sys.stderr)
            return 1
        write_key(a.key_out, a.user, store.rotate_key(a.user))
    elif a.cmd == "list":
        for n in store.names():
            print(f"{n}\tkey_id={store.get(n).key_id}")
    elif a.cmd == "remove":
        print("удалён" if store.remove(a.user) else "не найден")
    if a.cmd != "list":
        print("Перезапуск не нужен: сервер перечитывает users.json при входе.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
