"""
MFTP/1 — бинарный протокол кадров (frames) поверх TCP.

Каждый кадр:
    +--------+---------+--------+--------+-------+----------+-------------+
    | magic  | version | opcode | status | flags | meta_len | payload_len |
    | 2 B    | 1 B     | 1 B    | 1 B    | 1 B   | 2 B (BE) | 8 B (BE)    |
    +--------+---------+--------+--------+-------+----------+-------------+
    | meta: JSON UTF-8, meta_len байт                                      |
    | payload: сырые байты, payload_len байт (тело файла)                  |
    +---------------------------------------------------------------------+

Фиксированный заголовок — 16 байт, порядок байт — big-endian (network order).
"""
from __future__ import annotations

import json
import socket
import struct
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, BinaryIO, Callable, Optional

MAGIC = b"MF"
VERSION = 1
HEADER = struct.Struct(">2sBBBBHQ")  # 16 байт
HEADER_SIZE = HEADER.size
MAX_META = 64 * 1024 - 1          # meta_len — uint16
MAX_PAYLOAD = 4 * 1024 ** 3       # 4 ГиБ — защитный лимит на файл
CHUNK = 64 * 1024                 # размер блока потоковой передачи


class Op(IntEnum):
    # сервер -> клиент
    HELLO = 0x00
    # клиент -> сервер
    AUTH = 0x01
    LIST = 0x02
    UPLOAD = 0x03
    DOWNLOAD = 0x04
    DELETE = 0x05
    MKDIR = 0x06
    PING = 0x07
    BYE = 0x0F
    # ответы сервера
    OK = 0x80
    ERROR = 0x81
    DATA = 0x82


class Status(IntEnum):
    SUCCESS = 0x00
    BAD_REQUEST = 0x01
    AUTH_REQUIRED = 0x02
    AUTH_FAILED = 0x03
    KEY_REJECTED = 0x04
    NOT_FOUND = 0x05
    ALREADY_EXISTS = 0x06
    FORBIDDEN = 0x07
    TOO_LARGE = 0x08
    CHECKSUM_MISMATCH = 0x09
    RATE_LIMITED = 0x0A
    INTERNAL = 0xFF


class ProtocolError(Exception):
    def __init__(self, status: Status, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


class ConnectionClosed(Exception):
    pass


@dataclass
class Frame:
    opcode: int
    status: int = 0
    flags: int = 0
    meta: dict[str, Any] = field(default_factory=dict)
    payload_len: int = 0


def recv_exact(sock: socket.socket, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionClosed("peer closed connection")
        buf += chunk
    return bytes(buf)


def read_frame_header(sock: socket.socket) -> Frame:
    """Читает заголовок + meta. Payload остаётся в сокете и читается потоково."""
    magic, ver, opcode, status, flags, meta_len, payload_len = HEADER.unpack(
        recv_exact(sock, HEADER_SIZE))
    if magic != MAGIC:
        raise ProtocolError(Status.BAD_REQUEST, "bad magic")
    if ver != VERSION:
        raise ProtocolError(Status.BAD_REQUEST, f"unsupported version {ver}")
    if payload_len > MAX_PAYLOAD:
        raise ProtocolError(Status.TOO_LARGE, "payload too large")
    meta: dict[str, Any] = {}
    if meta_len:
        try:
            meta = json.loads(recv_exact(sock, meta_len).decode("utf-8"))
            if not isinstance(meta, dict):
                raise ValueError
        except (UnicodeDecodeError, ValueError):
            raise ProtocolError(Status.BAD_REQUEST, "meta must be a JSON object")
    return Frame(opcode, status, flags, meta, payload_len)


def send_frame(sock: socket.socket, opcode: int, meta: Optional[dict] = None,
               status: int = 0, payload: bytes = b"", payload_len: Optional[int] = None,
               flags: int = 0) -> None:
    """Отправляет кадр. Если передан payload_len без payload — тело
    дописывается вызывающим кодом (потоковая отдача файла)."""
    meta_bytes = json.dumps(meta or {}, ensure_ascii=False, separators=(",", ":")).encode()
    if len(meta_bytes) > MAX_META:
        raise ProtocolError(Status.INTERNAL, "meta too large")
    plen = len(payload) if payload_len is None else payload_len
    header = HEADER.pack(MAGIC, VERSION, opcode, status, flags, len(meta_bytes), plen)
    sock.sendall(header + meta_bytes + payload)


def stream_payload_to(sock: socket.socket, length: int, out: BinaryIO,
                      on_chunk: Optional[Callable[[bytes], None]] = None) -> None:
    remaining = length
    while remaining:
        chunk = sock.recv(min(CHUNK, remaining))
        if not chunk:
            raise ConnectionClosed("connection lost during transfer")
        out.write(chunk)
        if on_chunk:
            on_chunk(chunk)
        remaining -= len(chunk)


def discard_payload(sock: socket.socket, length: int) -> None:
    remaining = length
    while remaining:
        chunk = sock.recv(min(CHUNK, remaining))
        if not chunk:
            raise ConnectionClosed("connection lost")
        remaining -= len(chunk)
