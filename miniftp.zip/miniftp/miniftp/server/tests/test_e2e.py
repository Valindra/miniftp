"""Сквозной тест: поднимает сервер в отдельном процессе и гоняет весь протокол.
Запуск:  python -m pytest -q server/tests   (или просто python server/tests/test_e2e.py)
"""
import base64
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "app"
sys.path.insert(0, str(APP))
from accounts import compute_key_proof  # noqa: E402
from protocol import HEADER, MAGIC, VERSION, Op, Status, recv_exact  # noqa: E402

PORT = 22121


def send(s, op, meta=None, payload=b""):
    m = json.dumps(meta or {}).encode()
    s.sendall(HEADER.pack(MAGIC, VERSION, op, 0, 0, len(m), len(payload)) + m + payload)


def recv(s):
    magic, ver, op, st, fl, ml, pl = HEADER.unpack(recv_exact(s, HEADER.size))
    assert magic == MAGIC
    meta = json.loads(recv_exact(s, ml)) if ml else {}
    return op, st, meta, recv_exact(s, pl) if pl else b""


def parse_key(text):
    kv = dict(l.split("=", 1) for l in text.splitlines()[1:] if "=" in l)
    return kv["key_id"], base64.b64decode(kv["secret"])


def connect():
    s = socket.create_connection(("127.0.0.1", PORT), 5)
    op, _, meta, _ = recv(s)
    assert op == Op.HELLO
    return s, bytes.fromhex(meta["nonce"])


def login(key_id, secret, pwd="Test123331=", user="Test"):
    s, nonce = connect()
    send(s, Op.AUTH, {"user": user, "password": pwd, "key_id": key_id,
                      "key_proof": compute_key_proof(secret, nonce, user)})
    return s, recv(s)


def main():
    tmp = Path(tempfile.mkdtemp())
    env = dict(os.environ, MFTP_PORT=str(PORT), MFTP_STORAGE=str(tmp / "storage"),
               MFTP_USERS=str(tmp / "cfg/users.json"), MFTP_KEYS_DIR=str(tmp / "cfg/keys"),
               MFTP_BOOTSTRAP_USER="Test", MFTP_BOOTSTRAP_PASSWORD="Test123331=",
               MFTP_LOG_LEVEL="WARNING")
    proc = subprocess.Popen([sys.executable, "server.py"], cwd=APP, env=env)
    try:
        for _ in range(50):
            try:
                socket.create_connection(("127.0.0.1", PORT), 0.2).close()
                break
            except OSError:
                time.sleep(0.1)
        key_text = (tmp / "cfg/keys/Test.auth_token.key").read_text()
        key_id, secret = parse_key(key_text)

        # 1. Команда без входа
        s, _ = connect()
        send(s, Op.LIST, {"path": "/"})
        assert recv(s)[1] == Status.AUTH_REQUIRED
        s.close()

        # 2. Верный пароль, но нет ключа (пустое доказательство) -> отказ
        s, nonce = connect()
        send(s, Op.AUTH, {"user": "Test", "password": "Test123331=", "key_id": "", "key_proof": ""})
        assert recv(s)[1] == Status.KEY_REJECTED, "без ключа вход запрещён"
        s.close()

        # 3. Чужой ключ (неверный секрет) -> отказ
        s, r = login(key_id, os.urandom(32))
        assert r[1] == Status.KEY_REJECTED
        s.close()

        # 4. Неверный пароль -> отказ
        s, r = login(key_id, secret, pwd="wrong")
        assert r[1] == Status.AUTH_FAILED
        s.close()

        # 5. Успешный вход
        s, r = login(key_id, secret)
        assert r[0] == Op.OK, r

        # MKDIR + UPLOAD (1 МБ)
        send(s, Op.MKDIR, {"path": "/docs"}); assert recv(s)[0] == Op.OK
        data = os.urandom(1024 * 1024 + 7)
        send(s, Op.UPLOAD, {"path": "/docs/a.bin", "size": len(data),
                            "sha256": hashlib.sha256(data).hexdigest()}, data)
        assert recv(s)[0] == Op.OK

        # Повторная загрузка без overwrite -> ALREADY_EXISTS, поток не ломается
        send(s, Op.UPLOAD, {"path": "/docs/a.bin", "size": 3}, b"xyz")
        assert recv(s)[1] == Status.ALREADY_EXISTS
        # Битая контрольная сумма
        send(s, Op.UPLOAD, {"path": "/docs/b.bin", "size": 3, "sha256": "00"}, b"xyz")
        assert recv(s)[1] == Status.CHECKSUM_MISMATCH

        # LIST
        send(s, Op.LIST, {"path": "/docs"})
        op, st, meta, body = recv(s)
        entries = json.loads(body)
        assert [e["name"] for e in entries] == ["a.bin"], entries

        # DOWNLOAD
        send(s, Op.DOWNLOAD, {"path": "/docs/a.bin"})
        op, st, meta, body = recv(s)
        assert op == Op.DATA and body == data and meta["sha256"] == hashlib.sha256(data).hexdigest()

        # Path traversal
        send(s, Op.DOWNLOAD, {"path": "/../../etc/passwd"})
        assert recv(s)[1] in (Status.FORBIDDEN, Status.NOT_FOUND)

        # DELETE
        send(s, Op.DELETE, {"path": "/docs", "recursive": True}); assert recv(s)[0] == Op.OK
        send(s, Op.BYE); assert recv(s)[0] == Op.OK
        s.close()

        # 6. Многопоточность: 20 параллельных клиентов
        errors = []

        def worker(i):
            try:
                c, r = login(key_id, secret)
                assert r[0] == Op.OK
                blob = os.urandom(200_000)
                send(c, Op.UPLOAD, {"path": f"/p{i}.bin", "size": len(blob)}, blob)
                assert recv(c)[0] == Op.OK
                send(c, Op.DOWNLOAD, {"path": f"/p{i}.bin"})
                assert recv(c)[3] == blob
                c.close()
            except Exception as e:  # noqa
                errors.append(repr(e))

        ts = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
        [t.start() for t in ts]; [t.join() for t in ts]
        assert not errors, errors
        print("ALL TESTS PASSED")
    finally:
        proc.terminate()
        proc.wait(5)


def test_e2e():
    main()


if __name__ == "__main__":
    main()
