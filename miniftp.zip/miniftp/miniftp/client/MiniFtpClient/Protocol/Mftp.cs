using System.Buffers.Binary;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace MiniFtp.Client.Protocol;

/// <summary>Коды операций MFTP/1 (совпадают с server/app/protocol.py).</summary>
public enum Op : byte
{
    Hello = 0x00,
    Auth = 0x01,
    List = 0x02,
    Upload = 0x03,
    Download = 0x04,
    Delete = 0x05,
    Mkdir = 0x06,
    Ping = 0x07,
    Bye = 0x0F,
    Ok = 0x80,
    Error = 0x81,
    Data = 0x82,
}

public enum MftpStatus : byte
{
    Success = 0x00,
    BadRequest = 0x01,
    AuthRequired = 0x02,
    AuthFailed = 0x03,
    KeyRejected = 0x04,
    NotFound = 0x05,
    AlreadyExists = 0x06,
    Forbidden = 0x07,
    TooLarge = 0x08,
    ChecksumMismatch = 0x09,
    RateLimited = 0x0A,
    Internal = 0xFF,
    // клиентские (в сеть не передаются)
    ConnectionLost = 0xF0,
}

public sealed record FrameHeader(Op Op, MftpStatus Status, byte Flags, JsonObject Meta, long PayloadLength)
{
    public string MetaString(string key, string fallback = "") =>
        Meta.TryGetPropertyValue(key, out var v) && v is not null ? v.ToString() : fallback;
}

public sealed class MftpException : Exception
{
    public MftpStatus Status { get; }

    /// <summary>true — поток кадров нарушен (обрыв, мусор в канале), сеанс продолжать нельзя.</summary>
    public bool Fatal { get; }

    public MftpException(MftpStatus status, string message, bool fatal = false) : base(message)
    {
        Status = status;
        Fatal = fatal || status == MftpStatus.ConnectionLost;
    }
}

/// <summary>Сериализация кадров: 16-байтный заголовок (big-endian) + JSON meta + payload.</summary>
public static class FrameIO
{
    public const int HeaderSize = 16;
    public const byte Version = 1;
    public const int ChunkSize = 64 * 1024;
    private const byte M = (byte)'M', F = (byte)'F';

    private static readonly JsonSerializerOptions JsonOpts = new() { WriteIndented = false };

    public static async Task WriteHeaderAsync(Stream s, Op op, JsonObject? meta, long payloadLength,
                                              CancellationToken ct)
    {
        byte[] metaBytes = Encoding.UTF8.GetBytes((meta ?? new JsonObject()).ToJsonString(JsonOpts));
        if (metaBytes.Length > ushort.MaxValue)
            throw new MftpException(MftpStatus.BadRequest, "Метаданные кадра превышают 64 КБ");

        var buf = new byte[HeaderSize + metaBytes.Length];
        buf[0] = M; buf[1] = F;           // magic "MF"
        buf[2] = Version;                 // версия протокола
        buf[3] = (byte)op;                // код операции
        buf[4] = 0;                       // status (в запросах всегда 0)
        buf[5] = 0;                       // flags (зарезервировано)
        BinaryPrimitives.WriteUInt16BigEndian(buf.AsSpan(6, 2), (ushort)metaBytes.Length);
        BinaryPrimitives.WriteUInt64BigEndian(buf.AsSpan(8, 8), (ulong)payloadLength);
        metaBytes.CopyTo(buf, HeaderSize);
        await s.WriteAsync(buf, ct).ConfigureAwait(false);
    }

    public static async Task<FrameHeader> ReadHeaderAsync(Stream s, CancellationToken ct)
    {
        var h = new byte[HeaderSize];
        await s.ReadExactlyAsync(h, ct).ConfigureAwait(false);
        if (h[0] != M || h[1] != F)
            throw new MftpException(MftpStatus.BadRequest, "Неверная сигнатура кадра (это не MiniFTP-сервер?)", fatal: true);
        if (h[2] != Version)
            throw new MftpException(MftpStatus.BadRequest, $"Неподдерживаемая версия протокола: {h[2]}", fatal: true);

        ushort metaLen = BinaryPrimitives.ReadUInt16BigEndian(h.AsSpan(6, 2));
        ulong payloadLen = BinaryPrimitives.ReadUInt64BigEndian(h.AsSpan(8, 8));
        if (payloadLen > long.MaxValue)
            throw new MftpException(MftpStatus.TooLarge, "Некорректная длина данных", fatal: true);

        JsonObject meta = new();
        if (metaLen > 0)
        {
            var mb = new byte[metaLen];
            await s.ReadExactlyAsync(mb, ct).ConfigureAwait(false);
            meta = JsonNode.Parse(mb) as JsonObject
                   ?? throw new MftpException(MftpStatus.BadRequest, "meta не является JSON-объектом", fatal: true);
        }
        return new FrameHeader((Op)h[3], (MftpStatus)h[4], h[5], meta, (long)payloadLen);
    }

    /// <summary>Копирует ровно <paramref name="length"/> байт из src в dst с отчётом о прогрессе.</summary>
    public static async Task CopyExactAsync(Stream src, Stream dst, long length, Action<byte[], int>? onChunk,
                                            CancellationToken ct)
    {
        var buffer = new byte[ChunkSize];
        long remaining = length;
        while (remaining > 0)
        {
            int toRead = (int)Math.Min(buffer.Length, remaining);
            int n = await src.ReadAsync(buffer.AsMemory(0, toRead), ct).ConfigureAwait(false);
            if (n == 0) throw new MftpException(MftpStatus.ConnectionLost, "Соединение разорвано во время передачи");
            await dst.WriteAsync(buffer.AsMemory(0, n), ct).ConfigureAwait(false);
            onChunk?.Invoke(buffer, n);
            remaining -= n;
        }
    }
}
