using System.Security.Cryptography;
using System.Text;

namespace MiniFtp.Client.Security;

/// <summary>
/// Аппаратный ключ безопасности — файл <c>.auth_token.key</c> в корне USB-накопителя.
///
/// Формат (текст UTF-8, выпускается на сервере командой manage_users.py):
/// <code>
/// MFTP-KEY v1
/// user=Test
/// key_id=9f1c2a7be03d4410
/// secret=&lt;Base64, 32 байта&gt;
/// check=&lt;hex SHA-256("MFTP-KEY v1|user|key_id|secret")&gt;
/// </code>
///
/// Секрет на сервер НЕ передаётся. Сервер присылает случайный nonce, клиент
/// возвращает HMAC-SHA256(secret, nonce || user). Поэтому знание пароля без
/// физической флешки не даёт доступа, а перехват трафика не раскрывает секрет.
/// </summary>
public sealed record UsbKey(string User, string KeyId, byte[] Secret, string DriveRoot, string FilePath)
{
    public string ComputeProof(byte[] nonce)
    {
        byte[] user = Encoding.UTF8.GetBytes(User);
        byte[] msg = new byte[nonce.Length + user.Length];
        nonce.CopyTo(msg, 0);
        user.CopyTo(msg, nonce.Length);
        return Convert.ToHexString(HMACSHA256.HashData(Secret, msg)).ToLowerInvariant();
    }

    public string DisplayName => $"{DriveRoot.TrimEnd('\\')} (ключ {KeyId[..Math.Min(6, KeyId.Length)]}, пользователь {User})";
}

public sealed record KeyScanResult(IReadOnlyList<UsbKey> Keys, IReadOnlyList<string> Problems)
{
    public UsbKey? FindFor(string user) =>
        Keys.FirstOrDefault(k => string.Equals(k.User, user, StringComparison.Ordinal));
}

public static class UsbKeyLocator
{
    public const string KeyFileName = ".auth_token.key";
    private const string Header = "MFTP-KEY v1";

    /// <summary>
    /// Ищет ключи только на СЪЁМНЫХ накопителях (DriveType.Removable — USB-флешки,
    /// карты памяти). Ключ, скопированный на системный диск C:\, не принимается.
    /// </summary>
    public static KeyScanResult Scan()
    {
        var keys = new List<UsbKey>();
        var problems = new List<string>();

        foreach (var drive in SafeGetDrives())
        {
            try
            {
                if (drive.DriveType != DriveType.Removable || !drive.IsReady) continue;
                string path = Path.Combine(drive.RootDirectory.FullName, KeyFileName);
                if (!File.Exists(path)) continue;

                if (TryLoad(path, drive.RootDirectory.FullName, out var key, out var error))
                    keys.Add(key!);
                else
                    problems.Add($"{drive.Name}: {error}");
            }
            catch (IOException) { /* накопитель извлекли во время опроса */ }
            catch (UnauthorizedAccessException) { problems.Add($"{drive.Name}: нет доступа к файлу ключа"); }
        }
        return new KeyScanResult(keys, problems);
    }

    /// <summary>Быстрая проверка во время сеанса: та же флешка, тот же ключ.</summary>
    public static bool IsStillPresent(UsbKey key)
    {
        try
        {
            var drive = new DriveInfo(key.DriveRoot);
            if (drive.DriveType != DriveType.Removable || !drive.IsReady) return false;
            return TryLoad(key.FilePath, key.DriveRoot, out var current, out _)
                   && current!.KeyId == key.KeyId
                   && CryptographicOperations.FixedTimeEquals(current.Secret, key.Secret);
        }
        catch (Exception) { return false; }
    }

    public static bool TryLoad(string path, string driveRoot, out UsbKey? key, out string error)
    {
        key = null;
        var info = new FileInfo(path);
        if (info.Length > 4096) { error = "файл ключа слишком большой"; return false; }

        string[] lines = File.ReadAllLines(path, Encoding.UTF8);
        if (lines.Length == 0 || lines[0].Trim() != Header) { error = "неизвестный формат ключа"; return false; }

        var kv = lines.Skip(1)
            .Select(l => l.Trim())
            .Where(l => l.Contains('='))
            .Select(l => (k: l[..l.IndexOf('=')], v: l[(l.IndexOf('=') + 1)..]))
            .GroupBy(p => p.k).ToDictionary(g => g.Key, g => g.First().v);

        if (!kv.TryGetValue("user", out var user) || !kv.TryGetValue("key_id", out var keyId) ||
            !kv.TryGetValue("secret", out var secretB64) || !kv.TryGetValue("check", out var check))
        {
            error = "в ключе отсутствуют обязательные поля"; return false;
        }

        // контроль целостности (защита от повреждения/ручной правки файла)
        string expected = Checksum(user, keyId, secretB64);
        if (!CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(expected),
                                                     Encoding.ASCII.GetBytes(check.ToLowerInvariant())))
        {
            error = "контрольная сумма ключа не совпадает (файл повреждён)"; return false;
        }

        byte[] secret;
        try { secret = Convert.FromBase64String(secretB64); }
        catch (FormatException) { error = "секрет ключа повреждён"; return false; }
        if (secret.Length != 32) { error = "неверная длина секрета"; return false; }

        key = new UsbKey(user, keyId, secret, driveRoot, path);
        error = "";
        return true;
    }

    public static string Checksum(string user, string keyId, string secretB64) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{Header}|{user}|{keyId}|{secretB64}")))
               .ToLowerInvariant();

    /// <summary>
    /// Генерация содержимого ключа (тот же алгоритм, что в server/app/accounts.py).
    /// Используется для автономных тестов; боевой ключ выпускает сервер, т.к. ему
    /// нужно знать секрет для проверки HMAC.
    /// </summary>
    public static string Generate(string user, out string keyId, out byte[] secret)
    {
        keyId = Convert.ToHexString(RandomNumberGenerator.GetBytes(8)).ToLowerInvariant();
        secret = RandomNumberGenerator.GetBytes(32);
        string b64 = Convert.ToBase64String(secret);
        return $"{Header}\nuser={user}\nkey_id={keyId}\nsecret={b64}\ncheck={Checksum(user, keyId, b64)}\n";
    }

    /// <summary>Записывает выпущенный сервером ключ в корень флешки (скрытый, только чтение).</summary>
    public static void InstallToDrive(string sourceKeyFile, string driveRoot)
    {
        var drive = new DriveInfo(driveRoot);
        if (drive.DriveType != DriveType.Removable || !drive.IsReady)
            throw new InvalidOperationException("Выбранный диск не является готовым съёмным накопителем.");
        if (!TryLoad(sourceKeyFile, driveRoot, out _, out var err))
            throw new InvalidDataException($"Файл не является корректным ключом: {err}");

        string target = Path.Combine(drive.RootDirectory.FullName, KeyFileName);
        if (File.Exists(target)) File.SetAttributes(target, FileAttributes.Normal);
        File.Copy(sourceKeyFile, target, overwrite: true);
        File.SetAttributes(target, FileAttributes.Hidden | FileAttributes.ReadOnly);
    }

    public static IEnumerable<DriveInfo> RemovableDrives() =>
        SafeGetDrives().Where(d => { try { return d.DriveType == DriveType.Removable && d.IsReady; } catch { return false; } });

    private static DriveInfo[] SafeGetDrives()
    {
        try { return DriveInfo.GetDrives(); } catch (IOException) { return Array.Empty<DriveInfo>(); }
    }
}
