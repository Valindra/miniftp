using System.Text.Json;

namespace MiniFtp.Client.Models;

public sealed record RemoteEntry(string Name, string FullPath, bool IsDirectory, long Size, DateTime Modified);

/// <summary>Строка в панели файлов (локальной или удалённой).</summary>
public sealed class FileItem
{
    public required string Name { get; init; }
    public required string FullPath { get; init; }
    public bool IsDirectory { get; init; }
    public bool IsParent { get; init; }
    public long Size { get; init; }
    public DateTime? Modified { get; init; }

    public string Icon => IsParent ? "⮤" : IsDirectory ? "📁" : "📄";
    public string SizeText => IsDirectory ? "" : FormatSize(Size);
    public string ModifiedText => Modified?.ToString("dd.MM.yyyy HH:mm") ?? "";
    public string TypeText => IsParent ? "" : IsDirectory ? "Папка" :
        (Path.GetExtension(Name) is { Length: > 1 } ext ? ext[1..].ToUpperInvariant() + "-файл" : "Файл");

    public static string FormatSize(long bytes)
    {
        string[] units = { "Б", "КБ", "МБ", "ГБ", "ТБ" };
        double v = bytes; int i = 0;
        while (v >= 1024 && i < units.Length - 1) { v /= 1024; i++; }
        return i == 0 ? $"{bytes} {units[0]}" : $"{v:0.##} {units[i]}";
    }
}

/// <summary>Работа с путями сервера (всегда POSIX: "/dir/file").</summary>
public static class RemotePath
{
    public static string Combine(string dir, string name) =>
        dir.EndsWith('/') ? dir + name : dir + "/" + name;

    public static string Parent(string path)
    {
        string p = path.TrimEnd('/');
        int i = p.LastIndexOf('/');
        return i <= 0 ? "/" : p[..i];
    }
}

public sealed class AppSettings
{
    public string Host { get; set; } = "127.0.0.1";
    public int Port { get; set; } = 2121;
    public string User { get; set; } = "Test";
    public string LastLocalDir { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

    private static string FilePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MiniFtpClient", "settings.json");

    public static AppSettings Load()
    {
        try
        {
            return File.Exists(FilePath)
                ? JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new()
                : new();
        }
        catch { return new(); }
    }

    // пароль намеренно НЕ сохраняется
    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { /* не критично */ }
    }
}

/// <summary>Параметры сеанса, нужные для автоматического переподключения.</summary>
public sealed record SessionInfo(string Host, int Port, string User, string Password);
