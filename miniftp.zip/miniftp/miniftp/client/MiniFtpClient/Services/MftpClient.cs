using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using MiniFtp.Client.Models;
using MiniFtp.Client.Protocol;
using MiniFtp.Client.Security;

namespace MiniFtp.Client.Services;

public readonly record struct TransferProgress(string FileName, long Done, long Total);

/// <summary>
/// Клиент протокола MFTP/1. Одно TCP-соединение — один сеанс; команды
/// сериализуются семафором, т.к. протокол работает в режиме «запрос–ответ».
/// </summary>
public sealed class MftpClient : IAsyncDisposable
{
    private readonly TcpClient _tcp;
    private readonly NetworkStream _stream;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private byte[] _nonce = Array.Empty<byte>();
    private bool _broken;

    public string Host { get; }
    public int Port { get; }
    public string? User { get; private set; }
    public bool IsConnected => !_broken && _tcp.Connected;

    private MftpClient(TcpClient tcp, string host, int port)
    {
        _tcp = tcp;
        _stream = tcp.GetStream();
        Host = host;
        Port = port;
    }

    public static async Task<MftpClient> ConnectAsync(string host, int port, CancellationToken ct = default)
    {
        var tcp = new TcpClient { NoDelay = true, ReceiveBufferSize = 256 * 1024, SendBufferSize = 256 * 1024 };
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(10));
        bool tcpConnected = false;   // на каком этапе случился таймаут — для внятной диагностики
        try
        {
            await tcp.ConnectAsync(host, port, timeout.Token);
            tcpConnected = true;
            timeout.CancelAfter(TimeSpan.FromSeconds(15));   // отдельный срок на приветствие (туннель медленнее)
            var client = new MftpClient(tcp, host, port);
            // Клиент здоровается первым: «ленивые» TCP-туннели (CloudPub и др.) открывают
            // соединение до сервера только после первых байтов от клиента. Без этого обе
            // стороны ждут друг друга, и подключение отваливается по таймауту.
            await FrameIO.WriteHeaderAsync(client._stream, Op.Hello,
                new JsonObject { ["client"] = "MiniFTP-WPF", ["proto"] = 1 }, 0, timeout.Token);
            var hello = await FrameIO.ReadHeaderAsync(client._stream, timeout.Token);
            if (hello.Op == Op.Error)
                throw new MftpException(hello.Status, hello.MetaString("message", "сервер отклонил подключение"));
            if (hello.Op != Op.Hello)
                throw new MftpException(MftpStatus.BadRequest, "Сервер прислал неожиданное приветствие");
            client._nonce = Convert.FromHexString(hello.MetaString("nonce"));
            return client;
        }
        catch (System.Text.Json.JsonException)
        {
            tcp.Dispose();
            throw new MftpException(MftpStatus.BadRequest, "Сервер прислал некорректные данные", fatal: true);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            tcp.Dispose();
            throw new MftpException(MftpStatus.ConnectionLost, tcpConnected
                ? $"TCP-соединение с {host}:{port} установлено, но сервер не прислал приветствие за 15 с. " +
                  "Туннель принял подключение, но не довёл его до сервера: проверьте контейнеры на NAS и журнал агента."
                : $"Не удалось установить TCP-соединение с {host}:{port} за 10 с. Проверьте адрес и порт туннеля.");
        }
        catch (EndOfStreamException)
        {
            tcp.Dispose();
            throw new MftpException(MftpStatus.ConnectionLost,
                $"{host}:{port} закрыл соединение сразу после подключения: туннель не смог связаться с сервером.");
        }
        catch (SocketException ex)
        {
            tcp.Dispose();
            throw new MftpException(MftpStatus.ConnectionLost, $"Не удалось подключиться к {host}:{port}: {ex.Message}");
        }
        catch
        {
            tcp.Dispose();
            throw;
        }
    }

    // ------------------------------------------------------------------ команды

    public async Task AuthenticateAsync(string user, string password, UsbKey key, CancellationToken ct = default)
    {
        var meta = new JsonObject
        {
            ["user"] = user,
            ["password"] = password,
            ["key_id"] = key.KeyId,
            ["key_proof"] = key.ComputeProof(_nonce),   // HMAC(secret, nonce||user); сам секрет не передаётся
        };
        await RequestAsync(Op.Auth, meta, ct);
        User = user;
    }

    public async Task<List<RemoteEntry>> ListAsync(string path, CancellationToken ct = default)
    {
        await _gate.WaitAsync(ct);
        try
        {
            await FrameIO.WriteHeaderAsync(_stream, Op.List, new JsonObject { ["path"] = path }, 0, ct);
            var resp = await ReadResponseAsync(ct);
            var body = new byte[resp.PayloadLength];
            await _stream.ReadExactlyAsync(body, ct);
            string dir = resp.MetaString("path", path);
            var items = JsonSerializer.Deserialize<List<RemoteEntryDto>>(body) ?? new();
            return items.Select(d => new RemoteEntry(d.name, RemotePath.Combine(dir, d.name),
                                                     d.type == "dir", d.size,
                                                     DateTimeOffset.FromUnixTimeSeconds(d.mtime).LocalDateTime))
                        .ToList();
        }
        catch (Exception ex) when (IsFatal(ex)) { MarkBroken(); throw; }
        finally { _gate.Release(); }
    }

    public async Task UploadAsync(string localFile, string remotePath, bool overwrite,
                                  IProgress<TransferProgress>? progress, CancellationToken ct = default)
    {
        var info = new FileInfo(localFile);
        string sha = await Sha256FileAsync(localFile, ct);   // хэш до отправки — сервер сверит целостность

        await _gate.WaitAsync(ct);
        try
        {
            var meta = new JsonObject
            {
                ["path"] = remotePath,
                ["size"] = info.Length,
                ["sha256"] = sha,
                ["overwrite"] = overwrite,
            };
            await FrameIO.WriteHeaderAsync(_stream, Op.Upload, meta, info.Length, ct);

            long done = 0;
            await using (var fs = new FileStream(localFile, FileMode.Open, FileAccess.Read, FileShare.Read,
                                                 FrameIO.ChunkSize, FileOptions.SequentialScan | FileOptions.Asynchronous))
            {
                await FrameIO.CopyExactAsync(fs, _stream, info.Length, (_, n) =>
                {
                    done += n;
                    progress?.Report(new TransferProgress(info.Name, done, info.Length));
                }, ct);
            }
            await ReadResponseAsync(ct);
        }
        catch (Exception ex) when (IsFatal(ex)) { MarkBroken(); throw; }
        finally { _gate.Release(); }
    }

    public async Task DownloadAsync(string remotePath, string localFile, IProgress<TransferProgress>? progress,
                                    CancellationToken ct = default)
    {
        await _gate.WaitAsync(ct);
        string part = localFile + ".mftp-part";
        try
        {
            await FrameIO.WriteHeaderAsync(_stream, Op.Download, new JsonObject { ["path"] = remotePath }, 0, ct);
            var resp = await ReadResponseAsync(ct);
            string name = resp.MetaString("name", Path.GetFileName(localFile));
            string expected = resp.MetaString("sha256");
            long total = resp.PayloadLength;

            using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            long done = 0;
            await using (var fs = new FileStream(part, FileMode.Create, FileAccess.Write, FileShare.None,
                                                 FrameIO.ChunkSize, FileOptions.Asynchronous))
            {
                await FrameIO.CopyExactAsync(_stream, fs, total, (buf, n) =>
                {
                    hash.AppendData(buf, 0, n);
                    done += n;
                    progress?.Report(new TransferProgress(name, done, total));
                }, ct);
            }

            string actual = Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();
            if (expected.Length > 0 && actual != expected.ToLowerInvariant())
                throw new MftpException(MftpStatus.ChecksumMismatch, $"Файл {name} повреждён при передаче (SHA-256 не совпал)");

            File.Move(part, localFile, overwrite: true);
            if (resp.Meta.TryGetPropertyValue("mtime", out var mt) && mt is not null)
                File.SetLastWriteTime(localFile, DateTimeOffset.FromUnixTimeSeconds(mt.GetValue<long>()).LocalDateTime);
        }
        catch (Exception ex) when (IsFatal(ex)) { MarkBroken(); throw; }
        finally
        {
            _gate.Release();
            try { if (File.Exists(part)) File.Delete(part); } catch (IOException) { }
        }
    }

    public Task MkdirAsync(string path, CancellationToken ct = default) =>
        RequestAsync(Op.Mkdir, new JsonObject { ["path"] = path }, ct);

    public Task DeleteAsync(string path, bool recursive, CancellationToken ct = default) =>
        RequestAsync(Op.Delete, new JsonObject { ["path"] = path, ["recursive"] = recursive }, ct);

    public Task PingAsync(CancellationToken ct = default) => RequestAsync(Op.Ping, null, ct);

    // ---------------------------------------------------------------- служебное

    private async Task<FrameHeader> RequestAsync(Op op, JsonObject? meta, CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            await FrameIO.WriteHeaderAsync(_stream, op, meta, 0, ct);
            var resp = await ReadResponseAsync(ct);
            if (resp.PayloadLength > 0)   // команды без данных: payload не ожидается, но дочитываем для синхронизации
                await FrameIO.CopyExactAsync(_stream, Stream.Null, resp.PayloadLength, null, ct);
            return resp;
        }
        catch (Exception ex) when (IsFatal(ex)) { MarkBroken(); throw; }
        finally { _gate.Release(); }
    }

    private async Task<FrameHeader> ReadResponseAsync(CancellationToken ct)
    {
        var resp = await FrameIO.ReadHeaderAsync(_stream, ct);
        if (resp.Op == Op.Error)
            throw new MftpException(resp.Status, resp.MetaString("message", "ошибка сервера"));
        if (resp.Op is not (Op.Ok or Op.Data))
            throw new MftpException(MftpStatus.BadRequest, $"Неожиданный ответ сервера: {resp.Op}", fatal: true);
        return resp;
    }

    /// <summary>Ошибки, после которых поток кадров рассинхронизирован — сеанс нельзя продолжать.</summary>
    private static bool IsFatal(Exception ex) => ex switch
    {
        MftpException m => m.Fatal,
        OperationCanceledException => true,   // отмена посреди кадра
        IOException or SocketException or EndOfStreamException => true,
        ObjectDisposedException => true,
        _ => false,
    };

    private void MarkBroken()
    {
        _broken = true;
        try { _tcp.Close(); } catch { /* ignore */ }
    }

    private static async Task<string> Sha256FileAsync(string path, CancellationToken ct)
    {
        await using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read,
                                            FrameIO.ChunkSize, FileOptions.SequentialScan | FileOptions.Asynchronous);
        return Convert.ToHexString(await SHA256.HashDataAsync(fs, ct)).ToLowerInvariant();
    }

    public async ValueTask DisposeAsync()
    {
        if (IsConnected)
        {
            try
            {
                using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(2));
                await RequestAsync(Op.Bye, null, cts.Token);
            }
            catch { /* сервер мог уже закрыть соединение */ }
        }
        _tcp.Dispose();
        _gate.Dispose();
    }

    // DTO ответа LIST (имена полей — как в JSON сервера)
    private sealed record RemoteEntryDto(string name, string type, long size, long mtime);
}