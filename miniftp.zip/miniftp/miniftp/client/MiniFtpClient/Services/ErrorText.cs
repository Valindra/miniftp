using MiniFtp.Client.Protocol;

namespace MiniFtp.Client.Services;

public static class ErrorText
{
    public static string Describe(Exception ex) => ex switch
    {
        MftpException { Status: MftpStatus.AuthFailed } => "Неверный логин или пароль.",
        MftpException { Status: MftpStatus.KeyRejected } =>
            "Сервер отклонил USB-ключ: он не принадлежит этому пользователю или был отозван.",
        MftpException { Status: MftpStatus.RateLimited } =>
            "Слишком много неудачных попыток. Подождите минуту и попробуйте снова.",
        MftpException { Status: MftpStatus.NotFound } m => $"Не найдено: {m.Message}",
        MftpException { Status: MftpStatus.AlreadyExists } => "Объект с таким именем уже существует.",
        MftpException { Status: MftpStatus.Forbidden } => "Доступ к этому пути запрещён.",
        MftpException { Status: MftpStatus.ChecksumMismatch } m => m.Message,
        MftpException { Status: MftpStatus.TooLarge } m => $"Слишком большой объём: {m.Message}",
        MftpException m => m.Message,
        OperationCanceledException => "Операция отменена.",
        IOException io => $"Ошибка ввода-вывода: {io.Message}",
        UnauthorizedAccessException => "Нет прав доступа к локальному файлу или папке.",
        _ => ex.Message,
    };
}
