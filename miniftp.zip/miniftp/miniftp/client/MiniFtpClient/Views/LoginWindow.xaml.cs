using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using MiniFtp.Client.Models;
using MiniFtp.Client.Security;
using MiniFtp.Client.Services;

namespace MiniFtp.Client.Views;

public partial class LoginWindow : Window
{
    private readonly DispatcherTimer _keyPoll = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly AppSettings _settings = AppSettings.Load();
    private KeyScanResult _scan = new(Array.Empty<UsbKey>(), Array.Empty<string>());
    private bool _busy;

    public LoginWindow(string? notice)
    {
        InitializeComponent();
        if (notice is not null) StatusText.Text = notice;
    }

    // Нужен конструктор без параметров для StartupUri
    public LoginWindow() : this(null) { }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        HostBox.Text = _settings.Host;
        PortBox.Text = _settings.Port.ToString();
        UserBox.Text = _settings.User;
        (string.IsNullOrEmpty(UserBox.Text) ? (UIElement)UserBox : PasswordBox).Focus();

        // Опрос съёмных дисков раз в секунду: ключ «подхватывается» сразу после вставки флешки
        _keyPoll.Tick += (_, _) => RefreshKeyStatus();
        _keyPoll.Start();
        RefreshKeyStatus();
    }

    private void OnWindowClosed(object? sender, EventArgs e) => _keyPoll.Stop();

    private void RefreshKeyStatus()
    {
        _scan = UsbKeyLocator.Scan();
        var key = _scan.FindFor(UserBox.Text.Trim()) ?? _scan.Keys.FirstOrDefault();

        if (key is not null)
        {
            SetKeyPanel(ok: true, "🔑", "USB-ключ обнаружен", key.DisplayName);
        }
        else if (_scan.Problems.Count > 0)
        {
            SetKeyPanel(ok: false, "⚠", "Ключ на флешке недействителен", string.Join("; ", _scan.Problems));
        }
        else
        {
            SetKeyPanel(ok: false, "🔒", "Вставьте USB-ключ безопасности",
                        $"Файл {UsbKeyLocator.KeyFileName} в корне съёмного накопителя не найден");
        }
    }

    private void SetKeyPanel(bool ok, string icon, string title, string details)
    {
        KeyIcon.Text = icon;
        KeyTitle.Text = title;
        KeyDetails.Text = details;
        KeyPanel.BorderBrush = (Brush)FindResource(ok ? "Ok" : "Bad");
        KeyPanel.Background = new SolidColorBrush(ok ? Color.FromRgb(0xE6, 0xF4, 0xEA) : Color.FromRgb(0xFD, 0xEC, 0xEA));
    }

    private async void OnLogin(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        StatusText.Text = "";

        string host = HostBox.Text.Trim();
        string user = UserBox.Text.Trim();
        string password = PasswordBox.Password;
        if (host.Length == 0 || user.Length == 0 || password.Length == 0)
        {
            StatusText.Text = "Заполните адрес, логин и пароль.";
            return;
        }
        if (!int.TryParse(PortBox.Text, out int port) || port is < 1 or > 65535)
        {
            StatusText.Text = "Некорректный порт.";
            return;
        }

        // --- Проверка аппаратного ключа ДО обращения к серверу --------------------
        RefreshKeyStatus();
        var key = _scan.FindFor(user);
        if (key is null)
        {
            string reason = _scan.Keys.Count > 0
                ? $"Вставленный USB-ключ выдан другому пользователю ({_scan.Keys[0].User})."
                : "USB-ключ безопасности не обнаружен. Вставьте флешку с ключом.";
            StatusText.Text = "Доступ запрещён. " + reason;
            MessageBox.Show(this, reason, "Доступ запрещён", MessageBoxButton.OK, MessageBoxImage.Stop);
            return;
        }

        SetBusy(true, "Подключение…");
        MftpClient? client = null;
        try
        {
            client = await MftpClient.ConnectAsync(host, port);
            SetBusy(true, "Проверка учётных данных и ключа…");
            await client.AuthenticateAsync(user, password, key);

            _settings.Host = host; _settings.Port = port; _settings.User = user;
            _settings.Save();

            var main = new MainWindow(client, key, new SessionInfo(host, port, user, password), _settings);
            client = null; // владение передано главному окну
            main.Show();
            Close();
        }
        catch (Exception ex)
        {
            StatusText.Text = ErrorText.Describe(ex);
            PasswordBox.Clear();
            PasswordBox.Focus();
        }
        finally
        {
            if (client is not null) await client.DisposeAsync();
            SetBusy(false, null);
        }
    }

    private void SetBusy(bool busy, string? text)
    {
        _busy = busy;
        LoginButton.IsEnabled = !busy;
        Cursor = busy ? Cursors.Wait : null;
        if (text is not null) { StatusText.Foreground = (Brush)FindResource("Muted"); StatusText.Text = text; }
        else StatusText.Foreground = (Brush)FindResource("Bad");
    }

    private void OnInstallKey(object sender, RoutedEventArgs e)
    {
        var drives = UsbKeyLocator.RemovableDrives().ToList();
        if (drives.Count == 0)
        {
            MessageBox.Show(this, "Вставьте флешку, на которую нужно записать ключ.", "USB-ключ",
                            MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var dlg = new OpenFileDialog
        {
            Title = "Выберите файл ключа, выпущенный сервером (<логин>.auth_token.key)",
            Filter = "Ключ MiniFTP (*.key)|*.key|Все файлы (*.*)|*.*",
        };
        if (dlg.ShowDialog(this) != true) return;

        foreach (var d in drives)
        {
            string label = string.IsNullOrEmpty(d.VolumeLabel) ? "без метки" : d.VolumeLabel;
            var answer = MessageBox.Show(this, $"Записать ключ на диск {d.Name} ({label}, {FileItem.FormatSize(d.TotalSize)})?",
                                         "Запись USB-ключа", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (answer == MessageBoxResult.Cancel) return;
            if (answer != MessageBoxResult.Yes) continue;
            try
            {
                UsbKeyLocator.InstallToDrive(dlg.FileName, d.RootDirectory.FullName);
                MessageBox.Show(this, $"Ключ записан на {d.Name} (скрытый файл {UsbKeyLocator.KeyFileName}).\n" +
                                      "Удалите исходный файл ключа с компьютера и сервера.",
                                "Готово", MessageBoxButton.OK, MessageBoxImage.Information);
                RefreshKeyStatus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось записать ключ", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return;
        }
    }
}
