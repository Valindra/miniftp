using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using MiniFtp.Client.Models;
using MiniFtp.Client.Protocol;
using MiniFtp.Client.Security;
using MiniFtp.Client.Services;

namespace MiniFtp.Client.Views;

public partial class MainWindow : Window
{
    private const string RemoteDragFormat = "MiniFtp.RemotePaths";

    private MftpClient _client;
    private readonly UsbKey _key;
    private readonly SessionInfo _session;
    private readonly AppSettings _settings;

    private readonly DispatcherTimer _keyWatch = new() { Interval = TimeSpan.FromMilliseconds(1500) };
    private readonly DispatcherTimer _keepAlive = new() { Interval = TimeSpan.FromSeconds(60) };

    private string _localDir = "";
    private string _remoteDir = "/";
    private ListView? _activePane;
    private CancellationTokenSource? _transferCts;
    private bool _busy, _ending;
    private Point _dragStart;

    public MainWindow(MftpClient client, UsbKey key, SessionInfo session, AppSettings settings)
    {
        InitializeComponent();
        _client = client;
        _key = key;
        _session = session;
        _settings = settings;
    }

    // ================================================================ жизненный цикл

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Title = $"MiniFTP — {_session.User}@{_session.Host}:{_session.Port}";
        RemoteTitle.Text = $"🖧 Сервер  {_session.User}@{_session.Host}:{_session.Port}";
        KeyStatus.Text = "🔑";
        KeyStatus.ToolTip = "USB-ключ: " + _key.DisplayName;

        foreach (var d in DriveInfo.GetDrives().Where(d => d.IsReady))
            DriveBox.Items.Add(d.Name);

        string start = Directory.Exists(_settings.LastLocalDir)
            ? _settings.LastLocalDir
            : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        LoadLocal(start);
        await LoadRemoteAsync("/");

        // Сторож USB-ключа: флешку извлекли — сеанс немедленно завершается
        _keyWatch.Tick += (_, _) =>
        {
            if (!UsbKeyLocator.IsStillPresent(_key))
                EndSession("USB-ключ безопасности был извлечён. Сеанс завершён.");
        };
        _keyWatch.Start();

        // Keep-alive: сервер и туннель закрывают простаивающие соединения
        _keepAlive.Tick += async (_, _) =>
        {
            if (_busy || !_client.IsConnected) return;
            try { await _client.PingAsync(); } catch { /* переподключимся при следующей операции */ }
        };
        _keepAlive.Start();
        _activePane = LocalList;
    }

    private void OnWindowClosing(object? sender, CancelEventArgs e)
    {
        if (!_ending && _busy &&
            MessageBox.Show(this, "Идёт передача файлов. Прервать и выйти?", "MiniFTP",
                            MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
        {
            e.Cancel = true;
            return;
        }
        _keyWatch.Stop();
        _keepAlive.Stop();
        _transferCts?.Cancel();
        _settings.LastLocalDir = _localDir;
        _settings.Save();
        _ = _client.DisposeAsync().AsTask();
    }

    private void EndSession(string message)
    {
        if (_ending) return;
        _ending = true;
        _keyWatch.Stop();
        new LoginWindow(message).Show();
        Close();
    }

    private void OnDisconnect(object sender, RoutedEventArgs e) => EndSession("Сеанс завершён пользователем.");

    /// <summary>Переподключение после обрыва (новый nonce → новое HMAC-доказательство ключом).</summary>
    private async Task EnsureConnectedAsync()
    {
        if (_client.IsConnected) return;
        if (!UsbKeyLocator.IsStillPresent(_key))
            throw new MftpException(MftpStatus.KeyRejected, "USB-ключ не обнаружен");
        SetStatus("Соединение потеряно, переподключение…");
        var fresh = await MftpClient.ConnectAsync(_session.Host, _session.Port);
        try
        {
            await fresh.AuthenticateAsync(_session.User, _session.Password, _key);
        }
        catch
        {
            await fresh.DisposeAsync();
            throw;
        }
        var old = _client;
        _client = fresh;
        await old.DisposeAsync();
        SetStatus("Переподключено");
    }

    // ================================================================ панели

    private void LoadLocal(string dir)
    {
        try
        {
            var di = new DirectoryInfo(dir);
            var opts = new EnumerationOptions
            {
                IgnoreInaccessible = true,
                AttributesToSkip = FileAttributes.System | FileAttributes.Hidden,
            };
            var items = new List<FileItem>();
            if (di.Parent is not null)
                items.Add(new FileItem { Name = "..", FullPath = di.Parent.FullName, IsDirectory = true, IsParent = true });
            items.AddRange(di.EnumerateDirectories("*", opts).OrderBy(d => d.Name, StringComparer.OrdinalIgnoreCase)
                .Select(d => new FileItem { Name = d.Name, FullPath = d.FullName, IsDirectory = true, Modified = d.LastWriteTime }));
            items.AddRange(di.EnumerateFiles("*", opts).OrderBy(f => f.Name, StringComparer.OrdinalIgnoreCase)
                .Select(f => new FileItem { Name = f.Name, FullPath = f.FullName, Size = f.Length, Modified = f.LastWriteTime }));

            _localDir = di.FullName;
            LocalPathBox.Text = _localDir;
            LocalList.ItemsSource = items;
            DriveBox.SelectionChanged -= OnDriveChanged;
            DriveBox.SelectedItem = DriveBox.Items.Cast<string>()
                .FirstOrDefault(d => _localDir.StartsWith(d, StringComparison.OrdinalIgnoreCase));
            DriveBox.SelectionChanged += OnDriveChanged;
        }
        catch (Exception ex)
        {
            ShowError(ex);
            LocalPathBox.Text = _localDir;
        }
    }

    private async Task LoadRemoteAsync(string dir)
    {
        try
        {
            await EnsureConnectedAsync();
            var entries = await _client.ListAsync(dir);
            var items = new List<FileItem>();
            if (dir != "/")
                items.Add(new FileItem { Name = "..", FullPath = RemotePath.Parent(dir), IsDirectory = true, IsParent = true });
            items.AddRange(entries.Select(r => new FileItem
            {
                Name = r.Name, FullPath = r.FullPath, IsDirectory = r.IsDirectory, Size = r.Size, Modified = r.Modified,
            }));
            _remoteDir = dir;
            RemotePathBox.Text = dir;
            RemoteList.ItemsSource = items;
            SetStatus($"{entries.Count} объект(ов) в {dir}");
        }
        catch (Exception ex)
        {
            ShowError(ex);
            RemotePathBox.Text = _remoteDir;
        }
    }

    private async Task RefreshBothAsync()
    {
        LoadLocal(_localDir);
        await LoadRemoteAsync(_remoteDir);
    }

    private void OnLocalDoubleClick(object sender, MouseButtonEventArgs e) => OpenLocalSelection();
    private async void OnRemoteDoubleClick(object sender, MouseButtonEventArgs e) => await OpenRemoteSelectionAsync();

    private void OpenLocalSelection()
    {
        if (LocalList.SelectedItem is FileItem { IsDirectory: true } item) LoadLocal(item.FullPath);
    }

    private async Task OpenRemoteSelectionAsync()
    {
        if (RemoteList.SelectedItem is not FileItem item) return;
        if (item.IsDirectory) await LoadRemoteAsync(item.FullPath);
        else await DownloadAsync(new[] { item });
    }

    private void OnLocalUp(object sender, RoutedEventArgs e)
    {
        var parent = Directory.GetParent(_localDir);
        if (parent is not null) LoadLocal(parent.FullName);
    }

    private async void OnRemoteUp(object sender, RoutedEventArgs e)
    {
        if (_remoteDir != "/") await LoadRemoteAsync(RemotePath.Parent(_remoteDir));
    }

    private void OnDriveChanged(object sender, SelectionChangedEventArgs e)
    {
        if (DriveBox.SelectedItem is string d) LoadLocal(d);
    }

    private void OnLocalPathKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) LoadLocal(LocalPathBox.Text.Trim());
    }

    private async void OnRemotePathKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) await LoadRemoteAsync("/" + RemotePathBox.Text.Trim().Trim('/'));
    }

    private void OnRefreshLocal(object sender, RoutedEventArgs e) => LoadLocal(_localDir);
    private async void OnRefreshRemote(object sender, RoutedEventArgs e) => await LoadRemoteAsync(_remoteDir);
    private async void OnRefresh(object sender, RoutedEventArgs e) => await RefreshBothAsync();
    private void OnPaneFocus(object sender, RoutedEventArgs e) => _activePane = (ListView)sender;

    // ================================================================ горячие клавиши (как в WinSCP)

    private async void OnWindowKeyDown(object sender, KeyEventArgs e)
    {
        if (e.OriginalSource is TextBox) return;
        switch (e.Key)
        {
            case Key.F5:
                e.Handled = true;
                if (_activePane == LocalList) OnUpload(sender, e); else OnDownload(sender, e);
                break;
            case Key.F7:
                e.Handled = true;
                OnNewFolder(sender, e);
                break;
            case Key.Delete when _activePane == RemoteList:
                e.Handled = true;
                OnDelete(sender, e);
                break;
            case Key.R when Keyboard.Modifiers == ModifierKeys.Control:
                e.Handled = true;
                await RefreshBothAsync();
                break;
            case Key.Back:
                e.Handled = true;
                if (_activePane == RemoteList) OnRemoteUp(sender, e); else OnLocalUp(sender, e);
                break;
            case Key.Enter when _activePane is not null:
                e.Handled = true;
                if (_activePane == RemoteList) await OpenRemoteSelectionAsync(); else OpenLocalSelection();
                break;
        }
    }

    // ================================================================ команды

    private async void OnUpload(object sender, RoutedEventArgs e)
    {
        var paths = LocalList.SelectedItems.Cast<FileItem>().Where(i => !i.IsParent).Select(i => i.FullPath).ToList();
        if (paths.Count == 0) { SetStatus("Выделите файлы в левой панели"); return; }
        await UploadAsync(paths, _remoteDir);
    }

    private async void OnDownload(object sender, RoutedEventArgs e)
    {
        var items = RemoteList.SelectedItems.Cast<FileItem>().Where(i => !i.IsParent).ToList();
        if (items.Count == 0) { SetStatus("Выделите файлы в правой панели"); return; }
        await DownloadAsync(items);
    }

    private async void OnNewFolder(object sender, RoutedEventArgs e)
    {
        string? name = InputDialog.Ask(this, "Новая папка", "Имя папки на сервере:", "Новая папка");
        if (string.IsNullOrWhiteSpace(name)) return;
        if (name.IndexOfAny(new[] { '/', '\\', '\0' }) >= 0 || name is "." or "..")
        {
            ShowError(new ArgumentException("Недопустимое имя папки"));
            return;
        }
        try
        {
            await EnsureConnectedAsync();
            await _client.MkdirAsync(RemotePath.Combine(_remoteDir, name.Trim()));
            await LoadRemoteAsync(_remoteDir);
        }
        catch (Exception ex) { ShowError(ex); }
    }

    private async void OnDelete(object sender, RoutedEventArgs e)
    {
        var items = RemoteList.SelectedItems.Cast<FileItem>().Where(i => !i.IsParent).ToList();
        if (items.Count == 0) return;
        string what = items.Count == 1 ? $"«{items[0].Name}»" : $"{items.Count} объект(ов)";
        if (MessageBox.Show(this, $"Удалить на сервере {what}?\nПапки удаляются вместе с содержимым.", "Удаление",
                            MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            await EnsureConnectedAsync();
            foreach (var i in items) await _client.DeleteAsync(i.FullPath, recursive: i.IsDirectory);
        }
        catch (Exception ex) { ShowError(ex); }
        await LoadRemoteAsync(_remoteDir);
    }

    private void OnCancelTransfer(object sender, RoutedEventArgs e) => _transferCts?.Cancel();

    // ================================================================ передача файлов

    private async Task UploadAsync(IReadOnlyList<string> localPaths, string remoteDir)
    {
        await RunTransferAsync("Загрузка", async (progress, ct) =>
        {
            var existing = (await _client.ListAsync(remoteDir, ct)).Select(r => r.Name).ToHashSet();
            var conflicts = localPaths.Select(p => Path.GetFileName(p.TrimEnd(Path.DirectorySeparatorChar)))
                                      .Where(existing.Contains).ToList();
            bool? overwrite = AskOverwrite(conflicts);
            if (overwrite is null) return;
            foreach (var p in localPaths)
                await UploadEntryAsync(p, remoteDir, existing, overwrite.Value, progress, ct);
        });
        await LoadRemoteAsync(_remoteDir);
    }

    private async Task UploadEntryAsync(string localPath, string remoteDir, HashSet<string> existing, bool overwrite,
                                        IProgress<TransferProgress> progress, CancellationToken ct)
    {
        string name = Path.GetFileName(localPath.TrimEnd(Path.DirectorySeparatorChar));
        string target = RemotePath.Combine(remoteDir, name);

        if (Directory.Exists(localPath))
        {
            if (!existing.Contains(name)) await _client.MkdirAsync(target, ct);
            var inner = (await _client.ListAsync(target, ct)).Select(r => r.Name).ToHashSet();
            foreach (var child in Directory.EnumerateFileSystemEntries(localPath))
                await UploadEntryAsync(child, target, inner, overwrite, progress, ct);
            return;
        }
        if (existing.Contains(name) && !overwrite) return;   // пропустить существующий
        await _client.UploadAsync(localPath, target, overwrite, progress, ct);
    }

    private async Task DownloadAsync(IReadOnlyList<FileItem> items)
    {
        string localDir = _localDir;
        await RunTransferAsync("Скачивание", async (progress, ct) =>
        {
            var conflicts = items.Where(i => Path.Exists(Path.Combine(localDir, i.Name))).Select(i => i.Name).ToList();
            bool? overwrite = AskOverwrite(conflicts);
            if (overwrite is null) return;
            foreach (var i in items)
                await DownloadEntryAsync(i.FullPath, i.Name, i.IsDirectory, localDir, overwrite.Value, progress, ct);
        });
        LoadLocal(_localDir);
    }

    private async Task DownloadEntryAsync(string remotePath, string name, bool isDir, string localDir, bool overwrite,
                                          IProgress<TransferProgress> progress, CancellationToken ct)
    {
        string target = Path.Combine(localDir, name);
        if (isDir)
        {
            Directory.CreateDirectory(target);
            foreach (var child in await _client.ListAsync(remotePath, ct))
                await DownloadEntryAsync(child.FullPath, child.Name, child.IsDirectory, target, overwrite, progress, ct);
            return;
        }
        if (File.Exists(target) && !overwrite) return;
        await _client.DownloadAsync(remotePath, target, progress, ct);
    }

    /// <returns>true — перезаписывать, false — пропускать, null — отмена.</returns>
    private bool? AskOverwrite(IReadOnlyList<string> conflicts)
    {
        if (conflicts.Count == 0) return true;
        string list = string.Join("\n", conflicts.Take(8)) + (conflicts.Count > 8 ? $"\n… и ещё {conflicts.Count - 8}" : "");
        return MessageBox.Show(this, $"Уже существуют:\n{list}\n\nДа — перезаписать, Нет — пропустить.",
                               "Конфликт имён", MessageBoxButton.YesNoCancel, MessageBoxImage.Question) switch
        {
            MessageBoxResult.Yes => true,
            MessageBoxResult.No => false,
            _ => null,
        };
    }

    private async Task RunTransferAsync(string title, Func<IProgress<TransferProgress>, CancellationToken, Task> work)
    {
        if (_busy) { SetStatus("Дождитесь окончания текущей передачи"); return; }
        _busy = true;
        _transferCts = new CancellationTokenSource();
        TransferBar.Value = 0;
        TransferBar.Visibility = CancelButton.Visibility = Visibility.Visible;

        var progress = new Progress<TransferProgress>(p =>
        {
            TransferBar.Value = p.Total == 0 ? 100 : p.Done * 100.0 / p.Total;
            SetStatus($"{title}: {p.FileName} — {FileItem.FormatSize(p.Done)} из {FileItem.FormatSize(p.Total)}");
        });
        try
        {
            await EnsureConnectedAsync();
            await work(progress, _transferCts.Token);
            SetStatus($"{title}: завершено");
        }
        catch (Exception ex)
        {
            ShowError(ex);
        }
        finally
        {
            _busy = false;
            TransferBar.Visibility = CancelButton.Visibility = Visibility.Collapsed;
            _transferCts.Dispose();
            _transferCts = null;
        }
    }

    // ================================================================ drag & drop

    private void OnListMouseDown(object sender, MouseButtonEventArgs e) => _dragStart = e.GetPosition(null);

    private bool DragThresholdPassed(MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed) return false;
        var d = _dragStart - e.GetPosition(null);
        return Math.Abs(d.X) > SystemParameters.MinimumHorizontalDragDistance ||
               Math.Abs(d.Y) > SystemParameters.MinimumVerticalDragDistance;
    }

    private static bool OverItem(MouseEventArgs e)
    {
        for (var o = e.OriginalSource as DependencyObject; o is not null; o = VisualTreeHelper.GetParent(o))
            if (o is ListViewItem) return true;
        return false;
    }

    private void OnLocalMouseMove(object sender, MouseEventArgs e)
    {
        if (_busy || !DragThresholdPassed(e) || !OverItem(e)) return;
        var paths = LocalList.SelectedItems.Cast<FileItem>().Where(i => !i.IsParent).Select(i => i.FullPath).ToArray();
        if (paths.Length == 0) return;
        DragDrop.DoDragDrop(LocalList, new DataObject(DataFormats.FileDrop, paths), DragDropEffects.Copy);
    }

    private void OnRemoteMouseMove(object sender, MouseEventArgs e)
    {
        if (_busy || !DragThresholdPassed(e) || !OverItem(e)) return;
        var items = RemoteList.SelectedItems.Cast<FileItem>().Where(i => !i.IsParent).ToArray();
        if (items.Length == 0) return;
        DragDrop.DoDragDrop(RemoteList, new DataObject(RemoteDragFormat, items), DragDropEffects.Copy);
    }

    private void OnDragOverPane(object sender, DragEventArgs e)
    {
        bool ok = sender == RemoteList
            ? e.Data.GetDataPresent(DataFormats.FileDrop) && !e.Data.GetDataPresent(RemoteDragFormat)
            : e.Data.GetDataPresent(RemoteDragFormat);
        e.Effects = ok ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    // Файлы из левой панели или из Проводника Windows → на сервер
    private async void OnRemoteDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(DataFormats.FileDrop) is string[] paths && paths.Length > 0)
            await UploadAsync(paths, _remoteDir);
    }

    // Файлы из правой панели → в текущую локальную папку
    private async void OnLocalDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetData(RemoteDragFormat) is FileItem[] items && items.Length > 0)
            await DownloadAsync(items);
    }

    // ================================================================ вспомогательное

    private void SetStatus(string text) => StatusText.Text = text;

    private void ShowError(Exception ex)
    {
        string msg = ErrorText.Describe(ex);
        SetStatus("Ошибка: " + msg);
        if (ex is MftpException { Status: MftpStatus.KeyRejected })
        {
            EndSession(msg);
            return;
        }
        MessageBox.Show(this, msg, "MiniFTP", MessageBoxButton.OK,
                        ex is OperationCanceledException ? MessageBoxImage.Information : MessageBoxImage.Error);
    }
}
